DD_belatedPNG.fix('#logo img, a.views_slideshow_previous, a.views_slideshow_next, .transparency, .sidebar img');
