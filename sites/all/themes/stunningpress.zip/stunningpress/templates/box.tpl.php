<?php
// $Id$
?>
<!-- start box.tpl.php -->
<div class="dpbox">

<?php if ($title): ?>
  <h3 class="title"><?php print $title ?></h3>
<?php endif; ?>

  <div class="content"><?php print $content ?></div>
</div>
<!-- /end box.tpl.php -->