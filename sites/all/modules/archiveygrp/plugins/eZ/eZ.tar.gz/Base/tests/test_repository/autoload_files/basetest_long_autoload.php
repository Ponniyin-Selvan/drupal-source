<?php
return array(
	'trBasetestLongClass' => 'TestClasses/base_test_long_class.php',
);
?>
