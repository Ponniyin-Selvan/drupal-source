<?php
class erYourClass2
{
    function toString()
    {
      echo "Class 'erYourClass2'\n";
    }
}
?>