<?php
class erYourClass1
{
    function toString()
    {
      echo "Class 'erYourClass1'\n";
    }
}
?>