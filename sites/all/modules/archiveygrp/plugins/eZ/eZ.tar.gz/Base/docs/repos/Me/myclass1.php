<?php
class erMyClass1
{
    function toString()
    {
      echo "Class 'erMyClass1'\n";
    }
}
?>