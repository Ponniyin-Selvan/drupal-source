<?php
class extTranslationTest
{
}
?>
