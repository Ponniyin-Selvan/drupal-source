<?php
echo 'a\0a', "\n";
?>
