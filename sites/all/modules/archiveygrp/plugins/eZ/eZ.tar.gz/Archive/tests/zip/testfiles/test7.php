<?php
$voo = array( 'a' => 42 );
//xdebug_debug_zval( array( 'voo' ) );
xdebug_debug_zval( array( 'voo', 'a' ) );
?>
