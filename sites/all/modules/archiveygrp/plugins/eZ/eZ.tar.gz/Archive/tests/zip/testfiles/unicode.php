<?php
function 北方话北方話()
{
	echo "Hello world ";
}

北方话北方話();
?>
