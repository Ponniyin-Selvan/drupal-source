<?php
/**
 * File containing the ezcMailTransportSmtp class
 *
 * @package Mail
 * @version 1.5
 * @copyright Copyright (C) 2005-2008 eZ systems as. All rights reserved.
 * @license http://ez.no/licenses/new_bsd New BSD License
 */

/**
 * This class is deprecated. Use ezcMailSmtpTransport instead.
 *
 * @package Mail
 * @version 1.5
 * @ignore
 */
class ezcMailTransportSmtp extends ezcMailSmtpTransport
{
}
?>
