<?php
/**
 * File containing the ezcMailTransportMta class
 *
 * @package Mail
 * @version 1.5
 * @copyright Copyright (C) 2005-2008 eZ systems as. All rights reserved.
 * @license http://ez.no/licenses/new_bsd New BSD License
 */

/**
 * This class is deprecated. Use ezcMailMtaTransport instead.
 *
 * @package Mail
 * @version 1.5
 * @ignore
 */
class ezcMailTransportMta extends ezcMailMtaTransport
{
}
?>
